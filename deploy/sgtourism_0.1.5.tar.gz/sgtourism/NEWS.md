# 0.1.4
- new Shiny module for the new "Details" page
- refactor all the server side of the Shiny modules
- add more unit tests

# 0.1.3
- R package renamed sgtourism
- added popovers

# 0.1.2
- now passes R-CMD-Check.
- renamed df_prep.
- fixed shiny warning messages.
- added Dockerfile and renv.

# 0.1.1
- fixed req() for month selection.
- add download buttons.
- add tooltip on question marks with lorem ipsum text.
