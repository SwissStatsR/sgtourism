# create_gt_title() works

    Code
      create_gt_title(input = input, input_region = input$beobachtungsregion)
    Output
      <div>
        <b>Kanton St.Gallen, 2015</b>
        <small> (Veränderung ggü. 2016)</small>
      </div>

